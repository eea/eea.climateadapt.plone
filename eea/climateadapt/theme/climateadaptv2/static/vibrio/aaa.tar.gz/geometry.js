// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.12/esri/copyright.txt for details.
//>>built
define("esri/tasks/geometry","./GeometryService ./TrimExtendParameters ./BufferParameters ./AreasAndLengthsParameters ./LengthsParameters ./RelationParameters ./DensifyParameters ./GeneralizeParameters ./OffsetParameters ./DistanceParameters ./ProjectParameters".split(" "),function(){return{}});